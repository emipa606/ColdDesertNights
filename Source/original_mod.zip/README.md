# Cold Desert Nights
Adds configuration for the day/night temperature difference based on the tile's biome.