﻿namespace ColdDesertNights
{
    public enum TemperatureFunctions
    {
        Vanilla,
        Flatter,
        Flattest
    }
}
