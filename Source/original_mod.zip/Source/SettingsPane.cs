﻿namespace ColdDesertNights
{
    public enum SettingsPane
    {
        General,
        Weather,
        Conditions
    }
}
